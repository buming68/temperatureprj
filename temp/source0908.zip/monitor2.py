import sys
from PyQt5.QtWidgets import QApplication, QMainWindow

import configui2 as u1
import setting as u2

class SecondWindow(QMainWindow):
    def __init__(self, parent=None):
        super(SecondWindow, self).__init__(parent)
        self.ui = u2.Ui_settingForm()
        self.ui.setupUi(self)

class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.ui = u1.Ui_MainWindow()
        self.ui.setupUi(self)

    def slot1(self):
        # win.hide()
        # self.hide()

        win2.show()
        # win.setDisabled()
        # win.stop_send()  # 停止发送命令到串口
        # win.disconnect()
        # win.killTimer()



if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    win2 = SecondWindow()
    sys.exit(app.exec_())


# pip install pyinstaller
# pyinstaller --console --onefile monitor2.py
# pyinstaller -F -w --onefile monitor2.py
# pyinstaller -F -w --onefile monitor1.py

# pyinstaller -F  --onefile  --hidden-import="serial" monitor1.py

