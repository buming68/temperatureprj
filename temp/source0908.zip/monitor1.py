import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtGui import QRegExpValidator, QIntValidator, QDoubleValidator

import configui1 as u1
import setting as u2

class SecondWindow(QMainWindow):
    def __init__(self, parent=None):
        super(SecondWindow, self).__init__(parent)
        self.ui = u2.Ui_settingForm()
        self.ui.setupUi(self)

        portValidator = QIntValidator(0, 99)
        self.ui.lineEdit_10.setValidator(portValidator)
        self.ui.lineEdit_11.setValidator(portValidator)

    def closeEvent(self, event):
        win.show()

    def save_setting(self):

        print(self.ui.label_01.text())
        print(self.ui.lineEdit_10.text())
        print(self.ui.lineEdit_A10.text())
        print(self.ui.label_02.text())
        print(self.ui.lineEdit_11.text())
        print(self.ui.lineEdit_A11.text())





class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__(parent)
        self.ui = u1.Ui_MainWindow()
        self.ui.setupUi(self)

    def closeEvent(self, event):
        print("close main window")
        win2.close()

    def slot1(self):

        # print(self.ui.cfg_terminal_dic)
        if (self.ui.start_stop_button.text()) == "停止发送":
            # print("haha  ok")
            self.ui.stop_send()
            self.ui.timer1.cancel()

        self.hide()
        win2.show()




if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    win2 = SecondWindow()
    sys.exit(app.exec_())


# pip install pyinstaller
# pyinstaller --console --onefile monitor2.py
# pyinstaller -F -w --onefile monitor2.py
# pyinstaller -F -w --onefile monitor1.py

# pyinstaller -F  --onefile  --hidden-import="serial" monitor1.py

