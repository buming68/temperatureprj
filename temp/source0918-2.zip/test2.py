from loguru import logger



if __name__ == '__main__':
    logger.add('mywarn.log', retention='30 days', format="{time} {level} ")

    logger.debug('this is a debug message')
    logger.info('this is another debug message')
    logger.warning('this is another debug message')
    logger.error('this is another debug message')
    logger.info('this is another debug message')
    logger.success('this is success message!')
    logger.critical('this is critical message!')

